<?php

class C_admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->model(array('M_home'));
		$this->load->model(array('M_lembur'));
	}

	public function index()
	{
		// if(($this->session->userdata('ses_fitnes_username') == null) or ($this->session->userdata('ses_fitnes_pass') == null))
		// {
		// 	header('Location: '.base_url().'login');
		// }
		// else
		// {

		$tgl_from = '2023-01-01';
		$tgl_to = '2050-12-31';

		$list_transfer = $this->M_home->list_transfer($tgl_from, $tgl_to, '');


		$data = array(
			/* 'page' => 'page/home', */
			'page' => 'page/dash_home',
			'tgl_from' => $tgl_from,
			'tgl_to' => $tgl_to,
			'list_transfer' => $list_transfer,

		);

		$this->load->view('container.html', $data);
		//}
	}

	public function input_lembur()
	{
		$id_lembur = $this->M_lembur->get_id_lembur();
		$list_kantor = $this->M_lembur->list_kantor();
		$list_karyawan = $this->M_lembur->list_karyawan();

		$data = array(
			'page' => 'page/input_lembur',
			'id_lembur' => $id_lembur,
			'tanggal' => date('Y-m-d'),
			'list_kantor' => $list_kantor,
			'list_karyawan' => $list_karyawan,
		);


		$this->load->view('container.html', $data);
	}


	public function simpan_kirim()
	{
		if (!empty($_FILES['foto']['name'])) {
			$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
			$foto = $this->input->post('no_pengiriman', TRUE) . '.' . $ext;
			$this->do_upload('', $foto);

			$img_url = 'assets/images/upload/' . $foto;
		} else {
			$img_url = '';
		}


		$data = array(
			'no_pengiriman' => $this->input->post('no_pengiriman', TRUE),
			'tgl_kirim' => $this->input->post('tangal', TRUE),
			'kantor_kirim' => $this->input->post('kantor_kirim', TRUE),
			'kantor_terima' => $this->input->post('kantor_terima', TRUE),
			'pengirim' => $this->input->post('pengirim', TRUE),
			'keterangan' => $this->input->post('keterangan', TRUE),
			'img_kirim' => $img_url,
		);

		$id = $this->M_home->insert($data);


		//GENERATE QR CODE
		$this->load->library('ciqrcode'); //pemanggilan library QR CODE
		$config['cacheable']    = true; //boolean, the default is true
		$config['cachedir']     = './assets/'; //string, the default is application/cache/
		$config['errorlog']     = './assets/'; //string, the default is application/logs/
		$config['imagedir']     = './assets/images/barcode/'; //direktori penyimpanan qr code
		$config['quality']      = true; //boolean, the default is true
		$config['size']         = '1024'; //interger, the default is 1024
		$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
		$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
		$this->ciqrcode->initialize($config);

		$image_name = $this->input->post('no_pengiriman', TRUE); //buat name dari qr code sesuai dengan nim

		$params['data'] = $this->input->post('no_pengiriman', TRUE); //data yang akan di jadikan QR CODE
		$params['level'] = 'H'; //H=High
		$params['size'] = 10;
		$params['savename'] = FCPATH . $config['imagedir'] . $image_name . '.png'; //simpan image QR CODE ke folder assets/images/
		$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE


		//CETAK PDF
		$this->load->library('fpdf');
		$pdf = new FPDF("P", "mm", "A4");

		$get = $this->M_home->get_data2($this->input->post('no_pengiriman', TRUE));

		$pdf->AddPage();

		$pdf->SetFont("Arial", "B", "10"); //font header
		$pdf->SetXY(5, 5);
		$pdf->Cell(50, 3, 'PENGIRIMAN', 0, 1, 'C');
		$pdf->Cell(40, 3, 'No. ' . $this->input->post('no_pengiriman', TRUE), 0, 1, 'C');

		$pdf->Image(base_url() . 'assets/images/barcode/' . $image_name . '.png', 10, 15, 40, 40, 'png');

		$pdf->SetFont("Arial", "B", "8"); //font header
		$pdf->SetXY(5, 55);
		$pdf->Cell(100, 3, 'MOHON SCAN SAAT TERIMA BARANG', 0, 1, 'L');



		//print
		//    $this->load->library('escpos');
		// $connector = new Escpos\PrintConnectors\WindowsPrintConnector('pos2');
		// $connector = new WindowsPrintConnector('pos2');

		//    $printer = new Escpos\Printer($connector);
		//    $printer->initialize();
		//    $printer->selectPrintMode(Escpos\Printer::MODE_FONT_A);
		//    $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER);
		//    $printer->selectPrintMode(Escpos\Printer::MODE_DOUBLE_HEIGHT);
		//    $printer->text("NAMA_KANTOR");
		//    $printer->text("\n");
		//    $printer->text("GFD2012105101");

		//    $printer->cut();
		//    $printer->close();

		$this->session->set_flashdata('message', 'Data berhasil di simpan');

		//redirect(site_url(''));

		$pdf->Output('I', 'ID Card.pdf');
	}

	public function cari_data()
	{
		$no_pengiriman = $this->input->post('cari');

		$get = $this->M_home->get_data2($no_pengiriman);

		if (!empty($get)) {
			echo json_encode($get);
		} else {
			echo 'not';
		}
	}



	public function laporan()
	{

		if (empty($_GET['tgl_from'])) {
			$tgl_from = date('Y-m-01');
			$tgl_to = date('Y-m-t');
		} else {
			$tgl_from = $_GET['tgl_from'];
			$tgl_to = $_GET['tgl_to'];
		}

		$list_transfer = $this->M_home->list_transfer2($tgl_from, $tgl_to, '');

		$data = array(
			'page' => 'page/laporan',
			'tgl_from' => $tgl_from,
			'tgl_to' => $tgl_to,
			'list_transfer' => $list_transfer,
		);

		$this->load->view('container.html', $data);
	}

	function do_upload($id, $cek_bfr)
	{
		$this->load->library('upload');

		if ($cek_bfr != '') {
			@unlink('./assets/images/upload/' . $cek_bfr);
		}

		if (!empty($_FILES['foto']['name'])) {
			$config['upload_path'] = 'assets/images/upload/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '9999';
			//$config['max_widtd']  = '300';
			//$config['max_height']  = '300';
			$config['file_name']	= $cek_bfr;
			$config['overwrite']	= true;


			$this->upload->initialize($config);

			//Upload file 1
			if ($this->upload->do_upload('foto')) {
				$hasil = $this->upload->data();
			}
		}
	}
}

<?php
class M_home extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function list_kantor()
	{
		$data = $this->db->query("
				SELECT * FROM tb_kantor
				WHERE kode_kantor IN('MDN','PLG','LMP','JKT','CJR','BDG','KNG','SBY','OLN','PST')
			")->result();

		return $data;
	}

	function list_transfer($from, $to, $cari, $kode_kantor)
	{

		$data = $this->db->query("
				SELECT
				  id_transfer,
				  no_pengiriman,
				  tgl_kirim,
				  pengirim,
				  keterangan,
				  img_kirim,
				  tgl_terima,
				  penerima,
				  ttd,
				  img_terima,
				  DATE_FORMAT(tgl_ins,'%H:%i') AS jam_kirim,
				  CASE WHEN COALESCE(penerima,'') <> '' THEN 'TERKIRIM' ELSE 'PROSES' END AS status_transfer,
				  CASE WHEN kantor_kirim = 'MDN' THEN 'Medan' WHEN kantor_kirim = 'PLG' THEN 'Palembang'
				       WHEN kantor_kirim = 'LMP' THEN 'Lampung' WHEN kantor_kirim = 'JKT' THEN 'Jakarta'
				       WHEN kantor_kirim = 'CJR' THEN 'Cianjur' WHEN kantor_kirim = 'BDG' THEN 'Bandung'
				       WHEN kantor_kirim = 'KNG' THEN 'Kuningan' WHEN kantor_kirim = 'SBY' THEN 'Surabaya'
				       WHEN kantor_kirim = 'OLN' THEN 'Gudang Online' WHEN kantor_kirim = 'PST' THEN 'Gudang Pusat'
				   ELSE 'Tidak dikenal' END AS nama_kantor,
				   CASE WHEN kantor_terima = 'MDN' THEN 'Medan' WHEN kantor_terima = 'PLG' THEN 'Palembang'
				       WHEN kantor_terima = 'LMP' THEN 'Lampung' WHEN kantor_terima = 'JKT' THEN 'Jakarta'
				       WHEN kantor_terima = 'CJR' THEN 'Cianjur' WHEN kantor_terima = 'BDG' THEN 'Bandung'
				       WHEN kantor_terima = 'KNG' THEN 'Kuningan' WHEN kantor_terima = 'SBY' THEN 'Surabaya'
				       WHEN kantor_terima = 'OLN' THEN 'Gudang Online' WHEN kantor_terima = 'PST' THEN 'Gudang Pusat'
				   ELSE 'Tidak dikenal' END AS kantor_terima
				FROM
				  tb_transfer_barang
				WHERE tgl_kirim BETWEEN '" . $from . "' AND '" . $to . "' AND 
				/* (lower(kantor_kirim) LIKE '%" . $cari . "%' OR lower(keterangan) LIKE '%" . $cari . "%') AND COALESCE(penerima,'') = '' */
				(lower(keterangan) LIKE '%" . $cari . "%')
				" . $kode_kantor . "
			")->result();

		return $data;
	}

	function list_transfer2($from, $to, $cari)
	{
		$data = $this->db->query("
				SELECT
				  id_transfer,
				  no_pengiriman,
				  tgl_kirim,
				  pengirim,
				  keterangan,
				  img_kirim,
				  tgl_terima,
				  penerima,
				  ttd,
				  img_terima,
				  DATE_FORMAT(tgl_ins,'%H:%i') AS jam_kirim,
				  CASE WHEN COALESCE(penerima,'') <> '' THEN 'TERKIRIM' ELSE 'PROSES' END AS status_transfer,
				  ket_penerima,
				  tgl_ins,
				  tgl_updt,
				  CASE WHEN kantor_kirim = 'MDN' THEN 'Medan' WHEN kantor_kirim = 'PLG' THEN 'Palembang'
				       WHEN kantor_kirim = 'LMP' THEN 'Lampung' WHEN kantor_kirim = 'JKT' THEN 'Jakarta'
				       WHEN kantor_kirim = 'CJR' THEN 'Cianjur' WHEN kantor_kirim = 'BDG' THEN 'Bandung'
				       WHEN kantor_kirim = 'KNG' THEN 'Kuningan' WHEN kantor_kirim = 'SBY' THEN 'Surabaya'
				       WHEN kantor_kirim = 'OLN' THEN 'Gudang Online' WHEN kantor_kirim = 'PST' THEN 'Gudang Pusat'
				   ELSE 'Tidak dikenal' END AS kantor_kirim,
				  CASE WHEN kantor_terima = 'MDN' THEN 'Medan' WHEN kantor_terima = 'PLG' THEN 'Palembang'
				       WHEN kantor_terima = 'LMP' THEN 'Lampung' WHEN kantor_terima = 'JKT' THEN 'Jakarta'
				       WHEN kantor_terima = 'CJR' THEN 'Cianjur' WHEN kantor_terima = 'BDG' THEN 'Bandung'
				       WHEN kantor_terima = 'KNG' THEN 'Kuningan' WHEN kantor_terima = 'SBY' THEN 'Surabaya'
				       WHEN kantor_terima = 'OLN' THEN 'Gudang Online' WHEN kantor_terima = 'PST' THEN 'Gudang Pusat'
				   ELSE 'Tidak dikenal' END AS kantor_terima
				FROM
				  tb_transfer_barang
				WHERE tgl_kirim BETWEEN '" . $from . "' AND '" . $to . "' AND 
				(pengirim LIKE '%" . $cari . "%' OR keterangan LIKE '%" . $cari . "%') 
			")->result();

		return $data;
	}

	function get_data($id)
	{
		$data = $this->db->query("SELECT * FROM tb_transfer_barang
									  WHERE id_transfer = '" . $id . "'")->row();

		return $data;
	}

	function get_data2($no)
	{
		$data = $this->db->query("SELECT * FROM tb_transfer_barang
									  WHERE no_pengiriman = '" . $no . "'")->row();

		return $data;
	}

	function get_no_pengiriman()
	{
		/* $query = 
        	"
	            SELECT CONCAT('GFD',Y,M,'',ORD) AS no_pengiriman
	            FROM
	            (
	                SELECT
	                    Y,M,D,
	                    CASE
	                    WHEN (ORD >= 10 AND ORD < 99) THEN CONCAT('0',CAST(ORD AS CHAR))
	                    WHEN ORD >= 100 THEN CAST(ORD AS CHAR)
	                    ELSE CONCAT('00',CAST(ORD AS CHAR))
	                    END As ORD
	                From
	                (
	                    -- SELECT COUNT(no_costume)+1 AS ORD FROM tb_costumer
	                    SELECT
	                    -- CAST(LEFT(NOW(),4) AS CHAR) AS Y,
	                    CAST(MID(NOW(),3,2) AS CHAR) AS Y,
	                    CAST(MID(NOW(),6,2) AS CHAR) AS M,
	                    MID(NOW(),9,2) AS D,
	                    COALESCE(MAX(CAST(RIGHT(no_pengiriman,4) AS UNSIGNED)) + 1,1) AS ORD
	                    From tb_transfer_barang
	                    WHERE DATE(tgl_ins) = DATE(NOW())
	                ) AS A
	            ) AS AA;

	        "; */

		$query =
			"
				SELECT CONCAT('" . $this->input->post('kantor_kirim') . "',FRMTGL,'',ORD) AS no_pengiriman
				FROM
				(
				SELECT CONCAT(Y,M,D) AS FRMTGL,
					CASE
					WHEN (ORD >= 10 AND ORD < 99) THEN CONCAT('0',CAST(ORD AS CHAR))
					WHEN ORD >= 100 THEN CAST(ORD AS CHAR)
					ELSE CONCAT('00',CAST(ORD AS CHAR))
					END AS ORD
	                From
	                (
	                    -- SELECT COUNT(no_costume)+1 AS ORD FROM tb_costumer
	                    SELECT
	                    -- CAST(LEFT(NOW(),4) AS CHAR) AS Y,
	                    CAST(MID(NOW(),3,2) AS CHAR) AS Y,
	                    CAST(MID(NOW(),6,2) AS CHAR) AS M,
	                    MID(NOW(),9,2) AS D,
	                    COALESCE(MAX(CAST(RIGHT(no_pengiriman,3) AS UNSIGNED)) + 1,1) AS ORD
	                    From tb_transfer_barang
	                    WHERE DATE(tgl_ins) = DATE(NOW()) and kantor_kirim = '" . $this->input->post('kantor_kirim') . "'
	                ) AS A
	            ) AS AA;

	        ";

		$query = $this->db->query($query);

		if ($query->num_rows() > 0) {
			return $query->row()->no_pengiriman;
		} else {
			return false;
		}
	}

	function insert($data)
	{
		$this->db->insert('tb_transfer_barang', $data);
		return $this->db->insert_id();
	}

	function update($id, $data)
	{
		$this->db->where('id_transfer', $id)
			->update('tb_transfer_barang', $data);
	}
}

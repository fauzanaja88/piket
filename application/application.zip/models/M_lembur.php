<?php
class M_lembur extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function login($postData)
	{
		$data = $this->db->query("
				SELECT A.id_karyawan,no_karyawan,nama_karyawan,nama_jabatan,A.user,pass
				FROM tb_karyawan A
				LEFT JOIN tb_karyawan_jabatan B
				ON A.id_karyawan = B.id_karyawan AND A.kode_kantor = B.kode_kantor
				LEFT JOIN tb_jabatan C
				ON B.id_jabatan = C.id_jabatan AND B.kode_kantor = C.kode_kantor
				WHERE A.user = '" . $postData['user'] . "' AND pass = '" . base64_encode(md5($postData['pass'])) . "' AND isDefault = '1'
			")->row();

		return $data;
	}
	function list_kantor()
	{
		$data = $this->db->query("
				SELECT * FROM tb_kantor
				WHERE kode_kantor IN('MDN','PLG','LMP','JKT','CJR','BDG','KNG','SBY','OLN','PST')
			")->result();

		return $data;
	}
	function list_karyawan()
	{
		$data = $this->db->query("
		SELECT * FROM tb_karyawan WHERE isAktif = 'DITERIMA' AND isdefault = 1;
			")->result();

		return $data;
	}
	function ListKaryawanCabang($postData)
	{
		$data = $this->db->query("
		SELECT * FROM tb_karyawan WHERE isAktif = 'DITERIMA' AND isdefault = 1 and kode_kantor = '" . $postData['kode_kantor'] . "';
			")->result();

		return $data;
	}

	function List_absensi($id)
	{
		$data_lembur = $this->db->query("
		SELECT * from tb_approval_lembur where id_lembur = '" . $id . "';
			")->row();

		$data = $this->db->query("
		SELECT distinct B.nama_karyawan, B.id_karyawan,B.id_mesin_empl,A.tanggal 
		FROM tb_log_absen A
		LEFT JOIN tb_karyawan B ON A.id_karyawan = B.id_mesin_empl AND B.kode_kantor = '" . $data_lembur->kode_kantor . "'
		WHERE B.id_karyawan = '" . $data_lembur->id_karyawan . "'
		AND DATE_FORMAT(A.tanggal,'%Y-%m-%d') = '" . $data_lembur->tgl_lembur . "'
		ORDER BY tanggal;
			")->result();

		return $data;
	}
	function data_shift($id)
	{
		$data_lembur = $this->db->query("
		SELECT * from tb_approval_lembur where id_lembur = '" . $id . "';
			")->row();

		$data = $this->db->query("
			SELECT distinct b.nama_karyawan,a.*
			FROM tb_jam_kerja_karyawan a
			left join tb_karyawan b on b.id_karyawan = a.id_karyawan
			WHERE a.id_karyawan = '" . $data_lembur->id_karyawan . "' AND a.kode_kantor = '" . $data_lembur->kode_kantor . "'
			AND DATE_FORMAT(a.tanggal,'%Y-%m-%d') = '" . $data_lembur->tgl_lembur . "'
				")->result();

		return $data;
	}

	function cek_data_shift($id)
	{
		$data_lembur = $this->db->query("
		SELECT * from tb_approval_lembur where id_lembur = '" . $id . "';
			")->row();


		$data = $this->db->query("
			SELECT b.nama_karyawan,a.*
			FROM tb_jam_kerja_karyawan a
			left join tb_karyawan b on b.id_karyawan = a.id_karyawan
			WHERE a.id_karyawan = '" . $data_lembur->id_karyawan . "' AND a.kode_kantor = '" . $data_lembur->kode_kantor . "'
			AND DATE_FORMAT(a.tanggal,'%Y-%m-%d') = '" . $data_lembur->tgl_lembur . "'
				")->row();

		return $data;
	}
	function cek_data_shift2()
	{
		/* echo "<pre>" . $this->input->post('kode_kantor');
		print_r($this->input->post());
		die; */

		$data = $this->db->query("
			SELECT b.nama_karyawan,a.*
			FROM tb_jam_kerja_karyawan a
			left join tb_karyawan b on b.id_karyawan = a.id_karyawan
			WHERE a.id_karyawan = '" . $this->input->post('id_karyawan') . "' AND a.kode_kantor = '" . $this->input->post('kode_kantor') . "'
			AND DATE_FORMAT(a.tanggal,'%Y-%m-%d') = '" . $this->input->post('tgl_lembur') . "'
				")->row();

		return $data;
	}

	function get_all_lembur()
	{
		$data = $this->db->query("
		SELECT DISTINCT 
			CASE WHEN approval = 0 THEN 'Menunggu'
				 WHEN approval = 1 THEN 'Disetujui'
				 ELSE 'Ditolak' END AS status, b.`nama_karyawan`,a.*
		FROM tb_approval_lembur a
		LEFT JOIN tb_karyawan b ON (b.`id_karyawan` = a.`id_karyawan` AND b.`isDefault` = 1 )
		where a.user_ins = '" . $this->session->userdata('id_karyawan') . "'
			")->result();

		return $data;
	}
	function dash_approval()
	{
		$data['total'] = $this->db->query("
			SELECT count(*) as total
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "'")->row();

		$data['approved'] = $this->db->query("
			SELECT count(*) as approved
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "' and approval = 1")->row();

		$data['rejected'] = $this->db->query("
			SELECT count(*) as rejected
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "' and approval = 2")->row();

		return $data;
	}

	function get_all_approval()
	{
		$data = $this->db->query("
		SELECT DISTINCT 
			CASE WHEN approval = 0 THEN 'Menunggu'
				 WHEN approval = 1 THEN 'Disetujui'
				 ELSE 'Ditolak' END AS status, b.`nama_karyawan`,a.*
		FROM tb_approval_lembur a
		LEFT JOIN tb_karyawan b ON (b.`id_karyawan` = a.`id_karyawan` AND b.`isDefault` = 1 )
		where approval = 0
			")->result();

		return $data;
	}

	function list_lembur($from, $to, $cari)
	{
		$where = "";
		if (!in_array($this->session->userdata('nama_jabatan'), array('IT STAFF', 'HRD'))) {
			$where = " and a.user_ins = '" . $this->session->userdata('id_karyawan') . "'";
		}

		$data = $this->db->query("
		SELECT DISTINCT 
		CASE WHEN approval = 0 THEN 'Menunggu'
			 WHEN approval = 1 THEN 'Disetujui'
			 ELSE 'Ditolak' END AS status, b.`nama_karyawan`,a.*
		FROM tb_approval_lembur a
		LEFT JOIN tb_karyawan b ON (b.`id_karyawan` = a.`id_karyawan` AND b.`isDefault` = 1 )
		where tgl_lembur BETWEEN '" . $from . "' AND '" . $to . "' $where AND 
				(nama_karyawan	 LIKE '%" . $cari . "%' OR keterangan LIKE '%" . $cari . "%') #AND COALESCE(nama_karyawan,'') = ''
			")->result();

		return $data;
	}

	function detail_rekap_lembur($id_karyawan)
	{

		$data = $this->db->query("
		SELECT DISTINCT a.*,
		CASE WHEN approval = 0 THEN 'Menunggu'
			 WHEN approval = 1 THEN 'Disetujui'
			 ELSE 'Ditolak' END AS status, b.`nama_karyawan`
		FROM tb_approval_lembur a
		LEFT JOIN tb_karyawan b ON (b.`id_karyawan` = a.`id_karyawan` AND b.`isDefault` = 1 )
		where a.id_karyawan = '" . $id_karyawan . "' AND a.approval= 1 
			")->result();

		return $data;
	}

	function rekap_lembur($from, $to, $cari)
	{
		$where = "";
		if (!in_array($this->session->userdata('nama_jabatan'), array('IT STAFF', 'HRD'))) {
			$where = " and a.user_ins = '" . $this->session->userdata('id_karyawan') . "'";
		}
		$data = $this->db->query("
			SELECT a.id_karyawan, a.nama_karyawan ,a.nama_jabatan, a.kode_kantor, SUM(a.lama_lembur)as lama_lembur	
			FROM 
			(
				SELECT DISTINCT a.`id_karyawan`,b.`nama_karyawan`,d.`nama_jabatan`, a.`kode_kantor`,lama_lembur
				FROM tb_approval_lembur a 
				INNER JOIN tb_karyawan b ON (b.`id_karyawan` = a.`id_karyawan` AND b.`isDefault` = 1 ) 
				INNER JOIN tb_karyawan_jabatan c ON (c.`id_karyawan` = b.`id_karyawan` AND b.`kode_kantor`=c.`kode_kantor` )
				INNER JOIN tb_jabatan d ON d.`id_jabatan` = c.`id_jabatan` 
				WHERE a.approval = 1 and tgl_lembur BETWEEN '" . $from . "' AND '" . $to . "' $where AND 
			(nama_karyawan	 LIKE '%" . $cari . "%' OR a.keterangan LIKE '%" . $cari . "%') #AND COALESCE(nama_karyawan,'') = ''
			)a
			GROUP BY id_karyawan, nama_karyawan,nama_jabatan, kode_kantor")->result();


		return $data;
	}

	function get_data($id)
	{
		$data = $this->db->query("SELECT * FROM tb_approval_lembur
									  WHERE id_lembur = '" . $id . "'")->row();

		return $data;
	}

	function get_data2($no)
	{
		$data = $this->db->query("SELECT * FROM tb_transfer_barang
									  WHERE no_pengiriman = '" . $no . "'")->row();

		return $data;
	}

	function get_id_lembur($postData)
	{

		$query =
			"
			SELECT CONCAT('SPL',FRMTGL,ORD) AS id_lembur
			FROM
			(
				SELECT CONCAT(Y,M,D) AS FRMTGL
				,CASE
					WHEN (ORD >= 10 AND ORD < 99) THEN CONCAT('000',CAST(ORD AS CHAR))
					WHEN (ORD >= 100 AND ORD < 999) THEN CONCAT('00',CAST(ORD AS CHAR))
					WHEN (ORD >= 1000 AND ORD < 9999) THEN CONCAT('0',CAST(ORD AS CHAR))
					WHEN ORD >= 10000 THEN CAST(ORD AS CHAR)
					ELSE CONCAT('0000',CAST(ORD AS CHAR))
					END AS ORD
				FROM
				(
					SELECT
					CAST(LEFT(NOW(),4) AS CHAR) AS Y,
					CAST(MID(NOW(),6,2) AS CHAR) AS M,
					MID(NOW(),9,2) AS D,
					COALESCE(MAX(CAST(RIGHT(id_lembur,3) AS UNSIGNED)) + 1,1) AS ORD
					FROM tb_approval_lembur
					WHERE DATE(tgl_ins) = DATE(NOW()) 	
				) AS A
			) AS AA

	        ";

		$query = $this->db->query($query);
		if ($query->num_rows() > 0) {
			return $query->row()->id_lembur;
		} else {
			return false;
		}
	}

	function insert($data)
	{
		$this->db->insert('tb_approval_lembur', $data);
		return $this->db->insert_id();
	}

	function insert_hist($data)
	{

		$this->db->insert('tb_approval_lembur_hist', $data);
		return $this->db->insert_id();
	}

	function update($data)
	{
		$this->db->where('id_lembur', $data['id_lembur'])
			->update('tb_approval_lembur', $data);

		$menit    = $data['lama_lembur'] * (60);

		$query = "
			UPDATE tb_jam_kerja_karyawan SET
				jam_lembur = '" . $menit . "'
			WHERE id_karyawan = '" . $this->input->post('id_karyawan') . "' AND DATE_FORMAT(tanggal,'%Y-%m-%d') = '" . $this->input->post('tgl_lembur') . "'
			and kode_kantor = '" . $this->input->post('kode_kantor') . "'
			";
		$query = $this->db->query($query);
	}
	function delete($data)
	{
		$this->db->where('id_lembur', $data['id_lembur'])
			->delete('tb_approval_lembur', $data);
	}


	/* function updateBuku($kode_buku, $data)
    {
        $this->db->where('kode_buku', $kode_buku);
		$this->db->update('buku', $data);
    }
 */
}

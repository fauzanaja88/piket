<?php

class C_admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->model(array('M_home'));
		$this->load->model(array('M_lembur'));
		$this->load->library('form_validation');
	}

	public function index_pengiriman()
	{

		$tgl_from = '2023-01-01';
		$tgl_to = '2050-12-31';
		$list_kantor = $this->M_lembur->list_kantor();
		$kode_kantor = "";

		if ((!empty($_GET['kode_kantor'])) && ($_GET['kode_kantor'] != "")) {

			$kode_kantor = " and kantor_kirim = '" . $_GET['kode_kantor'] . "'";
		}

		if ((!empty($_GET['cari'])) && ($_GET['cari'] != "")) {
			$cari = $_GET['cari'];
		} else {
			$cari = "";
		}

		$list_transfer = $this->M_home->list_transfer($tgl_from, $tgl_to, $cari, $kode_kantor);


		$data = array(
			'page' => 'page/home',
			'tgl_from' => $tgl_from,
			'tgl_to' => $tgl_to,
			'list_transfer' => $list_transfer,
			'list_kantor' => $list_kantor,

		);

		$this->load->view('container.html', $data);
	}

	public function index()
	{
		/* echo "here";
		die; */
		if (!empty($this->input->post('user')) && !empty($this->input->post('pass'))) {

			/* echo "here";
			die; */
			/* $user = $this->input->post('user');
			$pass = $this->input->post('pass'); */
			$hasil	= $this->M_lembur->login($this->input->post());

			if ($hasil == TRUE) {
				$userdata = array(
					'id_karyawan'  => $hasil->id_karyawan,
					'user'    => $hasil->user,
					'nama_karyawan'   => ucfirst($hasil->nama_karyawan),
					'nama_jabatan' => $hasil->nama_jabatan,
				);
				$this->session->set_userdata($userdata);

				header('Location: ' . base_url() . 'dash-home');
			} else {
				$this->session->set_flashdata('message', 'Anda tidak memiliki akses!');
				$data = array(
					'page' => 'page/login',

				);

				$this->load->view('container.html', $data);
			}
		} else {

			$data = array(
				'page' => 'page/login',

			);

			$this->load->view('container.html', $data);
		}
	}

	public function dash_home()
	{

		$tgl_from = '2023-01-01';
		$tgl_to = '2050-12-31';

		if (!empty($this->session->userdata('id_karyawan'))) {
			$list_transfer = $this->M_home->list_transfer($tgl_from, $tgl_to, '', '');
			$_approval = $this->M_lembur->dash_approval($this->session->userdata());

			/* echo "<pre>herer";
			print_r($this->session->userdata());
			die; */

			$sql_total = "SELECT count(*) as total
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "'";
			$total = $this->db->query($sql_total)->row();

			$sql_apprv = "SELECT count(*) as apprv
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "' and approval = 1";
			$apprv = $this->db->query($sql_apprv)->row();

			$sql_reject = "SELECT count(*) as reject
			FROM tb_approval_lembur 
			WHERE user_ins = '" . $this->session->userdata('id_karyawan') . "' and approval = 2";
			$reject = $this->db->query($sql_reject)->row();

			$data = array(
				'page' => 'page/dash_home',
				'tgl_from' => $tgl_from,
				'tgl_to' => $tgl_to,
				'list_transfer' => $list_transfer,
				'total' => $total,
				'apprv' => $apprv,
				'reject' => $reject,

			);

			$this->load->view('container.html', $data);
		} else {
			redirect(site_url('index'));
		}
	}

	public function index_lembur()
	{
		/* $id_lembur = $this->M_lembur->get_id_lembur(); */
		$list_kantor = $this->M_lembur->list_kantor();

		$list_karyawan = $this->M_lembur->list_karyawan();
		$list_lembur = $this->M_lembur->get_all_lembur();

		if (!empty($this->session->userdata('id_karyawan'))) {

			$data = array(
				'page' => 'page/index_lembur',
				/* 'id_lembur' => $id_lembur, */
				'tanggal' => date('Y-m-d', strtotime(' -1 day')),
				'tgl_lembur' => date('Y-m-d', strtotime(' -2 day')),
				'list_kantor' => $list_kantor,
				'list_karyawan' => $list_karyawan,
				'list_lembur' => $list_lembur,
			);
			$this->load->view('container.html', $data);
		} else {
			redirect(site_url('index'));
		}
	}

	public function input_lembur()
	{
		/* $id_lembur = $this->M_lembur->get_id_lembur(); */
		$list_kantor = $this->M_lembur->list_kantor();

		if (!empty($this->session->userdata('id_karyawan'))) {
			$list_karyawan = $this->M_lembur->list_karyawan();

			$data = array(
				'page' => 'page/input_lembur',
				/* 'id_lembur' => $id_lembur, */
				'user_ins' => $this->session->userdata('id_karyawan'),
				'user_updt' => $this->session->userdata('id_karyawan'),
				'tanggal' => date('Y-m-d'),
				'tgl_lembur' => date('Y-m-d', strtotime(' -1 day')),
				'list_kantor' => $list_kantor,
				'list_karyawan' => $list_karyawan,
			);


			$this->load->view('container.html', $data);
		} else {
			redirect(site_url('index'));
		}
	}

	public function simpan_lembur()
	{
		$id_lembur = $this->M_lembur->get_id_lembur($this->input->post('kode_kantor'));

		if (!empty($_FILES['foto']['name'])) {
			$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
			$foto = time() . '_a.' . $ext;
			//$foto = $this->input->post('id_lembur', TRUE) . '.' . $ext;
			$this->do_upload('', $foto);

			$img_url = 'assets/images/upload/' . $foto;
			if (!empty($_FILES['foto2']['name'])) {
				$ext = pathinfo($_FILES['foto2']['name'], PATHINFO_EXTENSION);
				$foto2 = time() . '_b.' . $ext;
				$this->do_upload('', $foto2);

				$img_url2 = 'assets/images/upload/' . $foto2;
				if (!empty($_FILES['foto3']['name'])) {
					$ext = pathinfo($_FILES['foto3']['name'], PATHINFO_EXTENSION);
					$foto3 = time() . '_c.' . $ext;
					$this->do_upload('', $foto3);

					$img_url3 = 'assets/images/upload/' . $foto3;
				} else {
					$img_url3 = '';
				}
			} else {
				$img_url2 = '';
			}
		} else {
			$img_url = '';
			$img_url2 = '';
			$img_url3 = '';
		}

		$waktu_awal = strtotime($this->input->post('jam_mulai', TRUE));
		$waktu_akhir = strtotime($this->input->post('jam_selesai', TRUE)); // bisa juga waktu sekarang now()

		//menghitung selisih dengan hasil detik
		$diff = $waktu_akhir - $waktu_awal;

		//membagi detik menjadi jam
		$jam = floor($diff / (60 * 60));

		//membagi sisa detik setelah dikurangi $jam menjadi menit
		$menit    = $diff - $jam * (60 * 60);

		if ($menit > 30) {
			/* $jam += 1; */
		}

		$data = array(
			'id_lembur' => $id_lembur,
			'tgl_ins' => $this->input->post('tgl_ins', TRUE),
			'user_ins' => $this->input->post('user_ins', TRUE),
			'tgl_updt' => $this->input->post('tgl_ins', TRUE),
			'user_updt' => $this->input->post('user_updt', TRUE),
			'kode_kantor' => $this->input->post('kode_kantor', TRUE),
			'id_karyawan' => $this->input->post('id_karyawan', TRUE),
			'tgl_lembur' => $this->input->post('tgl_lembur', TRUE),
			'lama_lembur' => $this->input->post('lama_lembur', TRUE),
			'jam_mulai' => $this->input->post('jam_mulai', TRUE),
			'jam_selesai' => $this->input->post('jam_selesai', TRUE),
			'keterangan' => $this->input->post('keterangan', TRUE),
			'img_lembur' => $img_url,
			'img_lembur2' => $img_url2,
			'img_lembur3' => $img_url3,
		);

		$cek_data_shift2 = $this->M_lembur->cek_data_shift2($this->input->post());

		if (empty($cek_data_shift2)) {
			header('Location: ' . base_url() . 'input-lembur');
			$this->session->set_flashdata('message', 'Data Jam Kerja Belum di Input!');
		} else {
			$this->M_lembur->insert($data);

			header('Location: ' . base_url() . 'index-lembur');
			$this->session->set_flashdata('message', 'Data berhasil di simpan');
		}
	}

	public function logout()
	{
		/* $this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id'); */

		/* echo "<pre>here";
		print_r($this->session->userdata());
		die; */

		$this->session->unset_userdata('id_karyawan');

		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">You have been logged out!</div>');
		$data = array(
			'page' => 'page/login',

		);

		$this->load->view('container.html', $data);
	}

	public function edit_lembur()
	{
		$id = $this->uri->segment(3, 0);
		$list_kantor = $this->M_lembur->list_kantor();
		$list_karyawan = $this->M_lembur->list_karyawan();

		if (!empty($this->session->userdata('id_karyawan'))) {
			$list_karyawan = $this->M_lembur->list_karyawan();

			$get = $this->M_lembur->get_data($id);

			$data = array(
				'page' => 'page/edit_lembur',
				'get' => $get,
				'tanggal' => date('Y-m-d'),
				'list_kantor' => $list_kantor,
				'list_karyawan' => $list_karyawan,
			);

			$this->load->view('container.html', $data);
		} else {
			redirect(site_url('index'));
		}
	}


	public function update_lembur()
	{

		if (!empty($_FILES['foto']['name'])) {
			$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
			$foto = time() . '_a.' . $ext;
			//$foto = $this->input->post('id_lembur', TRUE) . '.' . $ext;
			$this->do_upload('', $foto);

			$img_url = 'assets/images/upload/' . $foto;
			if (!empty($_FILES['foto2']['name'])) {
				$ext = pathinfo($_FILES['foto2']['name'], PATHINFO_EXTENSION);
				$foto2 = time() . '_b.' . $ext;
				$this->do_upload('', $foto2);

				$img_url2 = 'assets/images/upload/' . $foto2;
				if (!empty($_FILES['foto3']['name'])) {
					$ext = pathinfo($_FILES['foto3']['name'], PATHINFO_EXTENSION);
					$foto3 = time() . '_c.' . $ext;
					$this->do_upload('', $foto3);

					$img_url3 = 'assets/images/upload/' . $foto3;
				} else {
					$img_url3 = '';
				}
			} else {
				$img_url2 = '';
			}
			echo "masuk<br>";
		} else {
			$img_url = '';
		}

		$waktu_awal = strtotime($this->input->post('jam_mulai', TRUE));
		$waktu_akhir = strtotime($this->input->post('jam_selesai', TRUE)); // bisa juga waktu sekarang now()

		//menghitung selisih dengan hasil detik
		$diff = $waktu_akhir - $waktu_awal;

		//membagi detik menjadi jam
		$jam = floor($diff / (60 * 60));

		//membagi sisa detik setelah dikurangi $jam menjadi menit
		$menit    = $diff - $jam * (60 * 60);

		if ($menit > 30) {
			/* $jam += 1; */
		}


		if (!empty($img_url)) {
			$data = array(
				'id_lembur' => $this->input->post('id_lembur', TRUE),
				'tgl_ins' => $this->input->post('tgl_ins', TRUE),
				'tgl_updt' => date('Y-m-d H:i:s'),
				'user_updt' => $this->input->post('user_updt', TRUE),
				'kode_kantor' => $this->input->post('kode_kantor', TRUE),
				'id_karyawan' => $this->input->post('id_karyawan', TRUE),
				'tgl_lembur' => $this->input->post('tgl_lembur', TRUE),
				'lama_lembur' => $this->input->post('lama_lembur', TRUE),
				'jam_mulai' => $this->input->post('jam_mulai', TRUE),
				'jam_selesai' => $this->input->post('jam_selesai', TRUE),
				'keterangan' => $this->input->post('keterangan', TRUE),
				'img_lembur' => $img_url,
			);
			if (!empty($img_url2)) {
				$data = array(
					'id_lembur' => $this->input->post('id_lembur', TRUE),
					'tgl_ins' => $this->input->post('tgl_ins', TRUE),
					'tgl_updt' => date('Y-m-d H:i:s'),
					'user_updt' => $this->input->post('user_updt', TRUE),
					'kode_kantor' => $this->input->post('kode_kantor', TRUE),
					'id_karyawan' => $this->input->post('id_karyawan', TRUE),
					'tgl_lembur' => $this->input->post('tgl_lembur', TRUE),
					'lama_lembur' => $this->input->post('lama_lembur', TRUE),
					'jam_mulai' => $this->input->post('jam_mulai', TRUE),
					'jam_selesai' => $this->input->post('jam_selesai', TRUE),
					'keterangan' => $this->input->post('keterangan', TRUE),
					'img_lembur' => $img_url,
					'img_lembur2' => $img_url2,
				);
				if (!empty($img_url3)) {
					$data = array(
						'id_lembur' => $this->input->post('id_lembur', TRUE),
						'tgl_ins' => $this->input->post('tgl_ins', TRUE),
						'tgl_updt' => date('Y-m-d H:i:s'),
						'user_updt' => $this->input->post('user_updt', TRUE),
						'kode_kantor' => $this->input->post('kode_kantor', TRUE),
						'id_karyawan' => $this->input->post('id_karyawan', TRUE),
						'tgl_lembur' => $this->input->post('tgl_lembur', TRUE),
						'lama_lembur' => $this->input->post('lama_lembur', TRUE),
						'jam_mulai' => $this->input->post('jam_mulai', TRUE),
						'jam_selesai' => $this->input->post('jam_selesai', TRUE),
						'keterangan' => $this->input->post('keterangan', TRUE),
						'img_lembur' => $img_url,
						'img_lembur2' => $img_url2,
						'img_lembur3' => $img_url3,
					);
				}
			}
		} else
			$data = array(
				'id_lembur' => $this->input->post('id_lembur', TRUE),
				'tgl_ins' => $this->input->post('tgl_ins', TRUE),
				'tgl_updt' => date('Y-m-d H:i:s'),
				'user_updt' => $this->input->post('user_updt', TRUE),
				'kode_kantor' => $this->input->post('kode_kantor', TRUE),
				'id_karyawan' => $this->input->post('id_karyawan', TRUE),
				'tgl_lembur' => $this->input->post('tgl_lembur', TRUE),
				'lama_lembur' => $this->input->post('lama_lembur', TRUE),
				'jam_mulai' => $this->input->post('jam_mulai', TRUE),
				'jam_selesai' => $this->input->post('jam_selesai', TRUE),
				'keterangan' => $this->input->post('keterangan', TRUE),
			);



		$this->M_lembur->update($data);
		header('Location: ' . base_url() . 'index-lembur');
		$this->session->set_flashdata('message', 'Data Lembur Berhasil dirubah');
	}
	public function form_approve()
	{
		$id = $this->uri->segment(3, 0);
		$list_kantor = $this->M_lembur->list_kantor();
		$list_karyawan = $this->M_lembur->list_karyawan();
		$list_absensi = $this->M_lembur->List_absensi($id);
		$data_shift = $this->M_lembur->data_shift($id);

		$get = $this->M_lembur->get_data($id);

		/* echo "here<pre>";
		print_r($data_shift);
		die; */

		$data = array(
			'page' => 'page/form_approve_lembur',
			'get' => $get,
			'tanggal' => date('Y-m-d'),
			'list_kantor' => $list_kantor,
			'list_karyawan' => $list_karyawan,
			'list_absensi' => $list_absensi,
			'data_shift' => $data_shift,
		);

		$this->load->view('container.html', $data);
	}

	public function approval_lembur()
	{
		/* $id_lembur = $this->M_lembur->get_id_lembur(); */
		$list_kantor = $this->M_lembur->list_kantor();

		$list_karyawan = $this->M_lembur->list_karyawan();
		$list_lembur = $this->M_lembur->get_all_approval();

		$data = array(
			'page' => 'page/approval_lembur',
			/* 'id_lembur' => $id_lembur, */
			'tanggal' => date('Y-m-d'),
			'tgl_lembur' => date('Y-m-d', strtotime(' -1 day')),
			'list_kantor' => $list_kantor,
			'list_karyawan' => $list_karyawan,
			'list_lembur' => $list_lembur,
		);


		$this->load->view('container.html', $data);
	}

	public function update_approval()
	{
		/* $id = $this->input->post('id_lembur', TRUE); */

		if ($this->input->post('isapprove') == "Y") {
			$approval = 1;
			$ket_apprv = "Di-Approve";
		} else {
			$approval = 2;
			$ket_apprv = "Di-Reject";
		}

		$waktu_awal = strtotime($this->input->post('jam_mulai', TRUE));
		$waktu_akhir = strtotime($this->input->post('jam_selesai', TRUE)); // bisa juga waktu sekarang now()

		//menghitung selisih dengan hasil detik
		$diff = $waktu_akhir - $waktu_awal;

		//membagi detik menjadi jam
		$jam = floor($diff / (60 * 60));

		//membagi sisa detik setelah dikurangi $jam menjadi menit
		$menit    = $diff - $jam * (60 * 60);

		if ($menit > 30) {
			/* $jam += 1; */
		}

		$data = array(
			'id_lembur' => $this->input->post('id_lembur', TRUE),
			'user_updt' => $this->session->userdata('id_karyawan'),
			'tgl_updt' => date('Y-m-d H:i:s'),
			'approval' => $approval,
			'note_approval' => $this->input->post('note_approval', TRUE),
			'jam_mulai' => $this->input->post('jam_mulai', TRUE),
			'jam_selesai' => $this->input->post('jam_selesai', TRUE),
			'lama_lembur' => $this->input->post('lama_lembur'),
		);

		/* echo "kemari<pre>here";
		print_r($data);
		die; */

		$cek_data_shift2 = $this->M_lembur->cek_data_shift2($this->input->post());

		if (empty($cek_data_shift2) && $approval == 1) {
			header('Location: ' . base_url() . 'input-lembur');
			$this->session->set_flashdata('message', 'Data Jam Kerja Belum di Input!');
		} else {
			$this->M_lembur->update($data);

			$data_hist = array(
				'id_lembur' => $this->input->post('id_lembur', TRUE),
				'user_ins' => $this->session->userdata('id_karyawan'),
				'tgl_ins' => date('Y-m-d'),
				'approval' => $approval,
				'note_approval' => $this->input->post('note_approval', TRUE),
			);
			$this->M_lembur->insert_hist($data_hist);

			if ($this->input->post('isapprove') == "Y") {
				$approval = 1;
				$ket_apprv = "Di-Approve";
			} else {
				$approval = 2;
				$ket_apprv = "Di-Reject";
			}

			header('Location: ' . base_url() . 'form-approval');
			$this->session->set_flashdata('message', 'Data Lembur Telah ' . $ket_apprv);
		}
	}

	public function delete()
	{
		$id = $this->uri->segment(3, 0);
		$data = array(
			'id_lembur' => $id,
		);

		$this->M_lembur->delete($data);
		header('Location: ' . base_url() . 'index-lembur');
		$this->session->set_flashdata('message', 'Data Lembur Berhasil di delete');
	}



	public function getKaryawanCabang()
	{
		// POST data
		$postData = $this->input->post();

		//load model
		$this->load->model('M_lembur');

		// get data
		$data = $this->M_lembur->ListKaryawanCabang($postData);

		echo json_encode($data);
	}

	public function input_pengiriman()
	{
		$no_pengiriman = $this->M_home->get_no_pengiriman();
		$list_kantor = $this->M_home->list_kantor();

		$data = array(
			'page' => 'page/input_pengiriman',
			'no_pengiriman' => $no_pengiriman,
			'tanggal' => date('Y-m-d'),
			'list_kantor' => $list_kantor,
		);

		$this->load->view('container.html', $data);
	}



	public function cari_karyawan()
	{
		$caribuku = $this->input->post('caribuku');
		$data['buku'] = $this->Mod_buku->BookSearch($caribuku);
		$this->load->view('peminjaman/peminjaman_searchbook', $data);
		// foreach($data['buku'] as $d) {
		//     print_r($d); die();
		// }
	}


	public function input_penerimaan()
	{
		$id = $this->uri->segment(2, 0);

		$get = $this->M_home->get_data($id);

		$data = array(
			'page' => 'page/input_penerimaan',
			'get' => $get,
			'tanggal' => date('Y-m-d'),
		);

		$this->load->view('container.html', $data);
	}

	public function simpan_kirim()
	{
		$no_pengiriman = $this->M_home->get_no_pengiriman();

		if (!empty($_FILES['foto']['name'])) {
			$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
			$foto = $this->input->post('no_pengiriman', TRUE) . '.' . $ext;
			$this->do_upload('', $foto);

			$img_url = 'assets/images/upload/' . $foto;
		} else {
			$img_url = '';
		}


		$data = array(
			/* 'no_pengiriman' => $this->input->post('no_pengiriman', TRUE), */
			'no_pengiriman' => $no_pengiriman,
			'tgl_kirim' => $this->input->post('tangal', TRUE),
			'kantor_kirim' => $this->input->post('kantor_kirim', TRUE),
			'kantor_terima' => $this->input->post('kantor_terima', TRUE),
			'pengirim' => $this->input->post('pengirim', TRUE),
			'keterangan' => $this->input->post('keterangan', TRUE),
			'img_kirim' => $img_url,
		);

		$id = $this->M_home->insert($data);


		//GENERATE QR CODE
		$this->load->library('ciqrcode'); //pemanggilan library QR CODE
		$config['cacheable']    = true; //boolean, the default is true
		$config['cachedir']     = './assets/'; //string, the default is application/cache/
		$config['errorlog']     = './assets/'; //string, the default is application/logs/
		$config['imagedir']     = './assets/images/barcode/'; //direktori penyimpanan qr code
		$config['quality']      = true; //boolean, the default is true
		$config['size']         = '1024'; //interger, the default is 1024
		$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
		$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
		$this->ciqrcode->initialize($config);

		/* $image_name = $this->input->post('no_pengiriman', TRUE); */ //buat name dari qr code sesuai dengan nim
		$image_name = $no_pengiriman; //buat name dari qr code sesuai dengan nim

		$params['data'] = $no_pengiriman; //data yang akan di jadikan QR CODE
		$params['level'] = 'H'; //H=High
		$params['size'] = 10;
		$params['savename'] = FCPATH . $config['imagedir'] . $image_name . '.png'; //simpan image QR CODE ke folder assets/images/
		$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE


		//CETAK PDF
		$this->load->library('fpdf');
		$pdf = new FPDF("P", "mm", "A4");

		$get = $this->M_home->get_data2($this->input->post('no_pengiriman', TRUE));

		$pdf->AddPage();

		$pdf->SetFont("Arial", "B", "10"); //font header
		$pdf->SetXY(5, 5);
		$pdf->Cell(50, 3, 'PENGIRIMAN', 0, 1, 'C');
		/* $pdf->Cell(40, 3, 'No. ' . $this->input->post('no_pengiriman', TRUE), 0, 1, 'C'); */
		$pdf->Cell(40, 3, 'No. ' . $no_pengiriman, 0, 1, 'C');

		$pdf->Image(base_url() . 'assets/images/barcode/' . $image_name . '.png', 10, 15, 40, 40, 'png');

		$pdf->SetFont("Arial", "B", "8"); //font header
		$pdf->SetXY(5, 55);
		$pdf->Cell(100, 3, 'MOHON SCAN SAAT TERIMA BARANG', 0, 1, 'L');



		//print
		//    $this->load->library('escpos');
		// $connector = new Escpos\PrintConnectors\WindowsPrintConnector('pos2');
		// $connector = new WindowsPrintConnector('pos2');

		//    $printer = new Escpos\Printer($connector);
		//    $printer->initialize();
		//    $printer->selectPrintMode(Escpos\Printer::MODE_FONT_A);
		//    $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER);
		//    $printer->selectPrintMode(Escpos\Printer::MODE_DOUBLE_HEIGHT);
		//    $printer->text("NAMA_KANTOR");
		//    $printer->text("\n");
		//    $printer->text("GFD2012105101");

		//    $printer->cut();
		//    $printer->close();

		$this->session->set_flashdata('message', 'Data berhasil di simpan');

		//redirect(site_url(''));

		$pdf->Output('I', 'ID Card.pdf');
	}

	public function cari_data()
	{
		$no_pengiriman = $this->input->post('cari');

		$get = $this->M_home->get_data2($no_pengiriman);

		if (!empty($get)) {
			echo json_encode($get);
		} else {
			echo 'not';
		}
	}

	public function simpan_terima()
	{
		$id_transfer = $this->input->post('id_transfer', TRUE);


		$data = array(
			'tgl_terima' => $this->input->post('tgl_terima', TRUE),
			'penerima' => $this->input->post('penerima', TRUE),
			'ket_penerima' => $this->input->post('ket_penerima', TRUE),
			'ttd' => $this->input->post('paraf', TRUE),
			'tgl_updt' => date('Y-m-d H:i:s'),
		);

		$this->M_home->update($id_transfer, $data);

		$this->session->set_flashdata('message', 'Data berhasil di simpan');
		redirect(site_url('index-pengiriman'));
	}

	public function laporan()
	{

		if (empty($_GET['tgl_from'])) {
			$tgl_from = date('Y-m-01');
			$tgl_to = date('Y-m-t');
		} else {
			$tgl_from = $_GET['tgl_from'];
			$tgl_to = $_GET['tgl_to'];
		}

		$list_transfer = $this->M_home->list_transfer2($tgl_from, $tgl_to, '', '');

		$data = array(
			'page' => 'page/laporan',
			'tgl_from' => $tgl_from,
			'tgl_to' => $tgl_to,
			'list_transfer' => $list_transfer,
		);

		$this->load->view('container.html', $data);
	}
	public function lap_lembur()
	{

		if (empty($_GET['tgl_from'])) {
			$tgl_from = date('Y-m-01');
			$tgl_to = date('Y-m-t');
		} else {
			$tgl_from = $_GET['tgl_from'];
			$tgl_to = $_GET['tgl_to'];
		}

		$list_lembur = $this->M_lembur->list_lembur($tgl_from, $tgl_to, '');

		$data = array(
			'page' => 'page/lap_lembur',
			'tgl_from' => $tgl_from,
			'tgl_to' => $tgl_to,
			'list_lembur' => $list_lembur,
		);

		$this->load->view('container.html', $data);
	}

	function do_upload($id, $cek_bfr)
	{
		$this->load->library('upload');

		if ($cek_bfr != '') {
			@unlink('./assets/images/upload/' . $cek_bfr);
		}

		if (!empty($_FILES['foto']['name'])) {
			$config['upload_path'] = 'assets/images/upload/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '9999';
			//$config['max_widtd']  = '300';
			//$config['max_height']  = '300';
			$config['file_name']	= $cek_bfr;
			$config['overwrite']	= true;


			$this->upload->initialize($config);

			//Upload file 1
			if ($this->upload->do_upload('foto')) {
				$hasil = $this->upload->data();
			}
		}
	}
}
